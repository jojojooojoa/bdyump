import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { BrainDumpForm } from "./BrainDumpForm";
import { BrainDumpHistory } from "./BrainDumpHistory";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b border-indigo-100 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 h-16 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-indigo-900">Mind Clarity</h2>
          <Authenticated>
            <SignOutButton />
          </Authenticated>
        </div>
      </header>
      
      <main className="max-w-4xl mx-auto p-6">
        <Content />
      </main>
      
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center py-8">
        <h1 className="text-4xl font-bold text-indigo-900 mb-4">
          Turn Brain Dumps into Clarity
        </h1>
        <Authenticated>
          <p className="text-lg text-indigo-700 max-w-2xl mx-auto">
            Feeling overwhelmed? Dump all your thoughts here and I'll help you find what matters most and your next clear action.
          </p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-lg text-indigo-700 mb-8">
            Sign in to transform your messy thoughts into clear, actionable insights
          </p>
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <div className="max-w-md mx-auto">
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        <div className="space-y-8">
          <BrainDumpForm />
          <BrainDumpHistory />
        </div>
      </Authenticated>
    </div>
  );
}
