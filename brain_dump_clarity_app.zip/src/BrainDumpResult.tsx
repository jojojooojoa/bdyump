import { useState } from "react";
import { Doc } from "../convex/_generated/dataModel";

interface BrainDumpResultProps {
  brainDump: Doc<"brainDumps">;
}

export function BrainDumpResult({ brainDump }: BrainDumpResultProps) {
  const [showOriginal, setShowOriginal] = useState(false);

  if (!brainDump.processed) {
    return (
      <div className="bg-white rounded-2xl shadow-lg border border-indigo-100 p-8">
        <div className="flex items-center gap-3 text-indigo-600">
          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-indigo-600"></div>
          <span className="font-medium">Processing your thoughts...</span>
        </div>
        <p className="text-gray-600 mt-2 text-sm">This usually takes 10-30 seconds</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-indigo-100 overflow-hidden">
      {/* Header with timestamp */}
      <div className="bg-indigo-50 px-8 py-4 border-b border-indigo-100">
        <div className="flex justify-between items-center">
          <span className="text-sm text-indigo-600 font-medium">
            {new Date(brainDump._creationTime).toLocaleDateString()} at{" "}
            {new Date(brainDump._creationTime).toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </span>
          <button
            onClick={() => setShowOriginal(!showOriginal)}
            className="text-sm text-indigo-600 hover:text-indigo-800 underline"
          >
            {showOriginal ? "Hide" : "Show"} original thoughts
          </button>
        </div>
      </div>

      <div className="p-8 space-y-6">
        {/* Original text (collapsible) */}
        {showOriginal && (
          <div className="bg-gray-50 rounded-xl p-4 border-l-4 border-gray-300">
            <h4 className="font-medium text-gray-700 mb-2">Your original thoughts:</h4>
            <p className="text-gray-600 text-sm leading-relaxed">{brainDump.originalText}</p>
          </div>
        )}

        {/* Summary */}
        <div className="bg-blue-50 rounded-xl p-6 border-l-4 border-blue-400">
          <h3 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
            <span className="text-lg">💙</span>
            Summary
          </h3>
          <p className="text-blue-800 leading-relaxed">{brainDump.summary}</p>
        </div>

        {/* What matters */}
        <div className="bg-green-50 rounded-xl p-6 border-l-4 border-green-400">
          <h3 className="font-semibold text-green-900 mb-3 flex items-center gap-2">
            <span className="text-lg">✨</span>
            What Matters Most
          </h3>
          <ul className="space-y-2">
            {brainDump.whatMatters.map((item, index) => (
              <li key={index} className="text-green-800 flex items-start gap-2">
                <span className="text-green-600 mt-1">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* What doesn't matter */}
        <div className="bg-orange-50 rounded-xl p-6 border-l-4 border-orange-400">
          <h3 className="font-semibold text-orange-900 mb-3 flex items-center gap-2">
            <span className="text-lg">🌊</span>
            Let These Go (For Now)
          </h3>
          <ul className="space-y-2">
            {brainDump.whatDoesnt.map((item, index) => (
              <li key={index} className="text-orange-800 flex items-start gap-2">
                <span className="text-orange-600 mt-1">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Actionable focus */}
        <div className="bg-purple-50 rounded-xl p-6 border-l-4 border-purple-400">
          <h3 className="font-semibold text-purple-900 mb-3 flex items-center gap-2">
            <span className="text-lg">🎯</span>
            Your Clear Next Action
          </h3>
          <p className="text-purple-800 font-medium text-lg leading-relaxed">
            {brainDump.actionableFocus}
          </p>
        </div>
      </div>
    </div>
  );
}
