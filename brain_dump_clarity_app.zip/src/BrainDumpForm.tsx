import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

export function BrainDumpForm() {
  const [text, setText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const createBrainDump = useMutation(api.brainDumps.createBrainDump);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    setIsSubmitting(true);
    try {
      await createBrainDump({ originalText: text.trim() });
      setText("");
      toast.success("Processing your thoughts... This will take a moment.");
    } catch (error) {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-indigo-100 p-8">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="brain-dump" className="block text-lg font-medium text-indigo-900 mb-3">
            What's on your mind?
          </label>
          <textarea
            id="brain-dump"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Just start typing... dump everything that's swirling around in your head. Don't worry about organization or grammar - just get it all out."
            className="w-full h-48 p-4 border border-indigo-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none text-gray-700 placeholder-gray-400 bg-indigo-50/30"
            disabled={isSubmitting}
          />
        </div>
        
        <button
          type="submit"
          disabled={!text.trim() || isSubmitting}
          className="w-full bg-indigo-600 text-white py-4 px-6 rounded-xl font-semibold text-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center gap-2">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              Finding clarity...
            </span>
          ) : (
            "Find My Clarity"
          )}
        </button>
      </form>
    </div>
  );
}
