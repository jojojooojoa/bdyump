import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { BrainDumpResult } from "./BrainDumpResult";

export function BrainDumpHistory() {
  const brainDumps = useQuery(api.brainDumps.getBrainDumps);

  if (!brainDumps || brainDumps.length === 0) {
    return null;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-indigo-900">Your Recent Clarity Sessions</h2>
      <div className="space-y-6">
        {brainDumps.map((brainDump) => (
          <BrainDumpResult key={brainDump._id} brainDump={brainDump} />
        ))}
      </div>
    </div>
  );
}
